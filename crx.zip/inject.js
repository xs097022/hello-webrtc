window.WETECWEBRTC = '喵';
